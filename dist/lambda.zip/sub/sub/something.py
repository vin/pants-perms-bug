"""This is just a module."""
def something():
    return 'yo'

