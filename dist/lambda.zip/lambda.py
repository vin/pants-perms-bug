from sub.sub import something

def handler(event, context):
  return something.something()
